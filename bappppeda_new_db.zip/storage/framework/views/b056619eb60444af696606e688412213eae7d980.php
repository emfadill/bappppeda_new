<?php $__env->startSection('title','Histori Surat'); ?>

<?php $__env->startSection('content'); ?> 

      <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Histori Surat</h4>
                    </div>
                    <!-- /.page title -->
                    
                </div>
                <!-- .row -->
                <div class="row">
                  <div class="col-md-12">
                        <div class="white-box">
                             <h3 class="box-title m-b-0">Surat Masuk</h3>
                            <p class="text-muted m-b-30">Histori surat masuk terbaru</p>
                            <div class="table-responsive">
                                <table id="myTable1" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Indeks</th>
                                            <th>Dari</th>
                                            <th>Perihal</th>
                                            <th>Tgl / Nomor Surat</th>
                                            <th>Tgl Surat Masuk</th>
                                            <th>Tgl Penyelesaian</th>
                                            <th>Jenis Surat</th>
                                            <th>Dokumen</th>
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <td><?php echo e($data->indeks); ?></td>
                                            <td><?php echo e($data->dari); ?></td>
                                            <td><?php echo e($data->perihal); ?></td>
                                            <td><?php echo e($data->tgl_no_suratmasuk); ?></td>
                                            <td><?php echo e($data->tgl_suratmasuk); ?></td>
                                            <td><?php echo e($data->tgl_penyelesaian); ?></td>
                                            <td><?php echo e($data->jenis_surat); ?></td>
                                            <td><a class="btn btn-block btn-primary fa fa-download" href="<?php echo e(asset('storage/surat_masuk/'.$data->dokumen)); ?>"></a></td>
                                            <td><a class="btn btn-block btn-primary fa fa-download" href="<?php echo e(asset('storage/surat_masuk/disposisi/'.$data->disposisi)); ?>"></a></td>
                                            <td><?php echo e($data->kepada); ?></td>
                                            <td><?php echo e($data->status); ?></td>
                                            <form action="<?php echo e(route('admin.pengaturan.delete',$data->id)); ?>" id="delete" method="POST">  <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('delete')); ?>


                                                <td><a class="btn btn-block btn-info fa fa-pencil" href="<?php echo e(route('admin.edit-akun',$data->id)); ?>"></a>

                                                    <a data-id="<?php echo e($data->id); ?>"  href="javascript:;" class="btn btn-block btn-danger fa fa-trash btn-del-cart"></a>
                                                </td>
                                            </form>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                 <!-- .row -->
                <div class="row">
                  <div class="col-md-12">
                        <div class="white-box">
                             <h3 class="box-title m-b-0">Surat Keluar</h3>
                            <p class="text-muted m-b-30">Histori surat keluar terbaru</p>
                            <div class="table-responsive">
                                <table id="myTable2" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Index</th>
                                            <th>Dari</th>
                                            <th>Tujuan</th>
                                            <th>Perihal</th>
                                            <th>Tgl / Nomor Surat</th>
                                            <th>Tgl Surat Keluar</th>
                                            <th>Jenis Surat</th>
                                            <th>Dokumen</th>
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $suratkeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <td><?php echo e($data->indeks); ?></td>
                                            <td><?php echo e($data->dari); ?></td>
                                            <td><?php echo e($data->tujuan); ?></td>
                                            <td><?php echo e($data->perihal); ?></td>
                                            <td><?php echo e($data->tgl_no_suratkeluar); ?></td>
                                            <td><?php echo e($data->tgl_suratkeluar); ?></td>
                                            <td><?php echo e($data->jenis_surat); ?></td>
                                            <td><a class="btn btn-block btn-primary fa fa-download" href="<?php echo e(asset('storage/surat_keluar/'.$data->dokumen)); ?>"></a></td>
                                            <td><a class="btn btn-block btn-primary fa fa-download" href="<?php echo e(asset('storage/surat_keluar/disposisi/'.$data->disposisi)); ?>"></a></td>
                                            <td><?php echo e($data->kepada); ?></td>
                                            <td><?php echo e($data->status); ?></td>
                                            <form action="<?php echo e(route('admin.pengaturan.delete',$data->id)); ?>" id="delete" method="POST">  <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('delete')); ?>


                                                <td><a class="btn btn-block btn-info fa fa-pencil" href="<?php echo e(route('admin.edit-akun',$data->id)); ?>"></a>

                                                    <a data-id="<?php echo e($data->id); ?>"  href="javascript:;" class="btn btn-block btn-danger fa fa-trash btn-del-cart"></a>
                                                </td>
                                            </form>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>