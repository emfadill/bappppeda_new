<?php $__env->startSection('title','Tambah Jabatan'); ?>

<?php $__env->startSection('content'); ?> 

  <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Tambah Jabatan</h4>
                    </div>
                    <!-- /.page title -->
                    
                </div>

                <div class="col-md-12">
                         <div class="white-box">
                            <h3 class="box-title m-b-0">Form Tambah Data Jabatan</h3>
                            <p class="text-muted m-b-30 font-13"> Isi form untuk jabatan </p>
                             <?php if($errors->count() > 0): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        <?php endif; ?>
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('admin.jabatan.create')); ?>">
                                <?php echo e(csrf_field()); ?>

                              
                                <div class="form-group">
                                    <label for="exampleInputEmail1" class="col-sm-3 control-label">Nama Jabatan</label>
                                    <div class="col-sm-9">
                                        <div class="input-group">
                                            <input type="text" class="form-control" id="exampleInputNama" placeholder="Masukkan Nama" name="name" value="<?php echo e(old('name')); ?>">
                                            <div class="input-group-addon"><i class="ti-user"></i></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group m-b-0">
                                    <div class="col-sm-offset-3 col-sm-9 text-right">
                                        <button type="submit" class="btn btn-info waves-effect waves-light m-t-10">Tambah</button>
                                        <a href="<?php echo e(route('admin.jabatan')); ?>" class="btn btn-info waves-effect waves-light m-t-10">Kembali</a>
                                    </div>
                                </div>
                               
                            </form>
                        </div>
                    </div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="js/sweetalert.min.js"></script>
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>