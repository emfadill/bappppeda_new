<?php $__env->startSection('title','Detail Disposisi Masuk Kabid'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Surat Masuk</h4>
                    </div>
                    <!-- /.page title -->
                    
                </div>
                <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                             <h3 class="box-title m-b-0">Surat Masuk</h3>
                            <div class="table-responsive">
                                <table id="myTable1" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Indeks</th>
                                            <th>Dari</th>
                                            <th>Perihal</th>
                                            <th>Tgl/Nomor Surat Masuk</th>
                                            <th>Tgl Surat Masuk</th>
                                            <th>Tgl Penyelesaian</th>
                                            <th>Jenis Surat</th>
                                            <th>Dokumen</th>
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($suratmasuk->id); ?></td>
                                            <td><?php echo e($suratmasuk->indeks); ?></td>
                                            <td><?php echo e($suratmasuk->dari); ?></td>
                                            <td><?php echo e($suratmasuk->perihal); ?></td>
                                            <td><?php echo e($suratmasuk->tgl_no_suratmasuk); ?></td>
                                            <td><?php echo e($suratmasuk->tgl_suratmasuk); ?></td>
                                            <td><?php echo e($suratmasuk->tgl_penyelesaian); ?></td>
                                            <?php if($suratmasuk->jenis_surat == 'Express'): ?>
                                                <td><h4><span class="label label-danger label-rouded"><?php echo e($suratmasuk->jenis_surat); ?></span></h4></td>
                                            <?php elseif($suratmasuk->jenis_surat == 'Standar'): ?>
                                                <td><h4><span class="label label-success label-rouded"><?php echo e($suratmasuk->jenis_surat); ?></span></h4></td>
                                            <?php endif; ?>
                                            <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#largeModal<?php echo e($suratmasuk->id); ?>">Tampil PDF</a>
                                                <a href="<?php echo e(action('Admin\AdminController@printPDF')); ?>" class="btn btn-primary">Tampil PDF</a>
                                            </td>
                                            <?php if($suratmasuk->url_disposisi != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalmasukDisposisi<?php echo e($suratmasuk->id); ?>">Disposisi</a></td>
                                            <?php else: ?>
                                            <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalmasukDisposisi<?php echo e($suratmasuk->id); ?>">Disposisi</a></td>
                                            <?php endif; ?>
                                            <td><?php echo e($suratmasuk->kepada); ?></td>
                                            <?php if($suratmasuk->status == 'Terkirim'): ?>
                                            <td><h4><span class="label label-info label-rouded"><?php echo e($suratmasuk->status); ?></span></h4></td>
                                            <?php elseif($suratmasuk->status == 'Sudah Disposisi'): ?>
                                            <td><h4><span class="label label-success label-rouded"><?php echo e($suratmasuk->status); ?></span></h4></td>
                                            <?php endif; ?>
                                        </tr>
                                        <div class="modal fade" id="largeModal<?php echo e($suratmasuk->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($suratmasuk->url_dokumen)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($suratmasuk->url_disposisi != null): ?>
                                        <div class="modal fade" id="largeModalmasukDisposisi<?php echo e($suratmasuk->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($suratmasuk->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Diteruskan Kekabid</h4>
                    </div>
                    <!-- /.page title -->
                    

                </div>

                  <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Data Surat Masuk Kabid</h3>
                            <div class="table-responsive">
                                <table id="myTable2" class="table table-striped">
                                    <thead>
                                        <tr>
                                             <th>No</th>
                                            <th>Jabatan</th>
                                            
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $DM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <?php if($data->get_user->kabid_id != null): ?>
                                            <td><?php echo e($data->get_user->get_kabid->name); ?></td>
                                            <?php else: ?>
                                            <td><?php echo e($data->get_user->get_jabatan->name); ?></td>
                                            <?php endif; ?>
                                            
                                                <?php if($data->url_disposisi != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalmasukDisposisi<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php else: ?>
                                            <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalmasukDisposisi<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php endif; ?>
                                            <td><?php echo e($data->kepada); ?></td>
                                            <?php if($data->kepada != null): ?>
                                            <td><a href="<?php echo e(route('admin.detaildm.subid',$data->id)); ?>" class="btn btn-danger">Detail Disposisi</a></td>
                                            <?php else: ?>
                                            <td></td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php if($data->url_disposisi != null): ?>
                                        <div class="modal fade" id="largeModalkeluarDisposisi<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($data->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                        <?php if($data->url_dokumen_ttd != null): ?>
                                            <div class="modal fade" id="largeModalkeluarTTD<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <iframe src="<?php echo e(url($data->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            
                        </div> 
                        </div>
                    </div>
                </div>



                <!-- /.row -->
                <script src="<?php echo e(asset('js/pdfobject.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>