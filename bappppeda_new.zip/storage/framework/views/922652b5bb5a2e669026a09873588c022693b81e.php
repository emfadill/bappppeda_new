<?php $__env->startSection('title','Detail Disposisi Keluar Kabid'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Surat Keluar</h4>
                    </div>
                    <!-- /.page title -->
                    
                </div>
                <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Data Surat Keluar</h3>
                            <div class="table-responsive">
                                <table id="myTable2" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Index</th>
                                            <th>Dari</th>
                                            <th>Tujuan</th>
                                            <th>Perihal</th>
                                            <th>Tgl/Nomor Surat Keluar</th>
                                            <th>Tgl Surat Keluar</th>
                                            <th>Jenis Surat</th>
                                            <th>Dokumen</th>
                                            <th>Dokumen Tanda Tangan</th>
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($suratkeluar->id); ?></td>
                                            <td><?php echo e($suratkeluar->indeks); ?></td>
                                            <td><?php echo e($suratkeluar->dari); ?></td>
                                            <td><?php echo e($suratkeluar->tujuan); ?></td>
                                            <td><?php echo e($suratkeluar->perihal); ?></td>
                                            <td><?php echo e($suratkeluar->tgl_no_suratkeluar); ?></td>
                                            <td><?php echo e($suratkeluar->tgl_suratkeluar); ?></td>
                                            <?php if($suratkeluar->jenis_surat == 'Express'): ?>
                                                <td><h4><span class="label label-danger label-rouded"><?php echo e($suratkeluar->jenis_surat); ?></span></h4></td>
                                            <?php elseif($suratkeluar->jenis_surat == 'Standar'): ?>
                                                <td><h4><span class="label label-success label-rouded"><?php echo e($suratkeluar->jenis_surat); ?></span></h4></td>
                                            <?php endif; ?>
                                            <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#largeModalkeluar<?php echo e($suratkeluar->id); ?>">Tampil PDF</a>
                                                <a href="<?php echo e(action('Admin\AdminController@printPDF')); ?>" class="btn btn-primary">Tampil PDF</a>
                                            <?php if($suratkeluar->url_dokumen_ttd != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalkeluarTTD<?php echo e($suratkeluar->id); ?>">Tampil PDF</a></td>
                                            <?php else: ?>
                                                <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalkeluarTTD<?php echo e($suratkeluar->id); ?>">Tampil PDF</a></td>
                                            <?php endif; ?>
                                                <?php if($suratkeluar->url_disposisi != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalkeluarDisposisi<?php echo e($suratkeluar->id); ?>">Disposisi</a></td>
                                            <?php else: ?>
                                            <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalkeluarDisposisi<?php echo e($suratkeluar->id); ?>">Disposisi</a></td>
                                            <?php endif; ?>
                                            <td><?php echo e($suratkeluar->kepada); ?></td>
                                            <?php if($suratkeluar->status == 'Terkirim'): ?>
                                            <td><h4><span class="label label-info label-rouded"><?php echo e($suratkeluar->status); ?></span></h4></td>
                                            <?php elseif($suratkeluar->status == 'Sudah Disposisi'): ?>
                                            <td><h4><span class="label label-success label-rouded"><?php echo e($suratkeluar->status); ?></span></h4></td>
                                            <?php endif; ?>
                                        </tr>
                                        <div class="modal fade" id="largeModalkeluar<?php echo e($suratkeluar->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($suratkeluar->url_dokumen)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($suratkeluar->url_disposisi != null): ?>
                                        <div class="modal fade" id="largeModalkeluarDisposisi<?php echo e($suratkeluar->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($suratkeluar->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                        <?php if($suratkeluar->url_dokumen_ttd != null): ?>
                                            <div class="modal fade" id="largeModalkeluarTTD<?php echo e($suratkeluar->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <iframe src="<?php echo e(url($suratkeluar->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            
                        </div> 
                        </div>
                    </div>
                </div>

                 <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Diteruskan Kekabid</h4>
                    </div>
                    <!-- /.page title -->
                    

                </div>

                  <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Data Surat Keluar Kabid</h3>
                            <div class="table-responsive">
                                <table id="myTable2" class="table table-striped">
                                    <thead>
                                        <tr>
                                             <th>No</th>
                                            <th>Jabatan</th>
                                            
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $DK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <?php if($data->get_user->kabid_id != null): ?>
                                            <td><?php echo e($data->get_user->get_kabid->name); ?></td>
                                            <?php else: ?>
                                            <td><?php echo e($data->get_user->get_jabatan->name); ?></td>
                                            <?php endif; ?>
                                            
                                                <?php if($data->url_disposisi != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalkeluarDisposisiKabid<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php else: ?>
                                            <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalkeluarDisposisiKabid<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php endif; ?>
                                            <td><?php echo e($data->kepada); ?></td>
                                            <?php if($data->kepada != null): ?>
                                            <td><a href="<?php echo e(route('admin.detaildk.subid',$data->id)); ?>" class="btn btn-danger">Detail Disposisi</a></td>
                                            <?php else: ?>
                                            <td></td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php if($data->url_disposisi != null): ?>
                                        <div class="modal fade" id="largeModalkeluarDisposisiKabid<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($data->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            
                        </div> 
                        </div>
                    </div>
                </div>



                <!-- /.row -->
                <script src="<?php echo e(asset('js/pdfobject.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>