<?php $__env->startSection('title','Menu Utama'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Surat Masuk Terbaru</h4>
                    </div>
                    <!-- /.page title -->
                    
                </div>
                <!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                             <h3 class="box-title m-b-0">Data Surat Masuk</h3>
                            <p class="text-muted m-b-30">List surat masuk terbaru</p>
                            <div class="table-responsive">
                                <table id="myTable1" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Indeks</th>
                                            <th>Dari</th>
                                            <th>Perihal</th>
                                            <th>Tgl/Nomor Surat Masuk</th>
                                            <th>Tgl Surat Masuk</th>
                                            <th>Tgl Penyelesaian</th>
                                            <th>Jenis Surat</th>
                                            <th>Dokumen</th>
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <td><?php echo e($data->indeks); ?></td>
                                            <td><?php echo e($data->dari); ?></td>
                                            <td><?php echo e($data->perihal); ?></td>
                                            <td><?php echo e($data->tgl_no_suratmasuk); ?></td>
                                            <td><?php echo e($data->tgl_suratmasuk); ?></td>
                                            <td><?php echo e($data->tgl_penyelesaian); ?></td>
                                            <?php if($data->jenis_surat == 'Express'): ?>
                                                <td><h4><span class="label label-danger label-rouded"><?php echo e($data->jenis_surat); ?></span></h4></td>
                                            <?php elseif($data->jenis_surat == 'Standar'): ?>
                                                <td><h4><span class="label label-success label-rouded"><?php echo e($data->jenis_surat); ?></span></h4></td>
                                            <?php endif; ?>
                                            <td><a href="#" class="btn btn-info" data-toggle="modal" data-target="#largeModal<?php echo e($data->id); ?>">Preview<br>&<br>Cetak Surat</a>
                                            </td>
                                            <?php if($data->url_disposisi != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalmasukDisposisi<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php else: ?>
                                            <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalmasukDisposisi<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php endif; ?>
                                            <td><?php echo e($data->kepada); ?></td>
                                            <?php if($data->status == 'Terkirim'): ?>
                                            <td><h4><span class="label label-info label-rouded"><?php echo e($data->status); ?></span></h4></td>
                                            <td></td>
                                            <?php elseif($data->status == 'Sudah Disposisi'): ?>
                                            <td><h4><span class="label label-success label-rouded"><?php echo e($data->status); ?></span></h4></td>
                                            <td><a href="<?php echo e(route('admin.detaildm.kabid',$data->id)); ?>" class="btn btn-danger">Detail Disposisi</a></td>
                                            <?php endif; ?>

                                        </tr>
                                        <div class="modal fade" id="largeModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($data->url_dokumen)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($data->url_disposisi != null): ?>
                                        <div class="modal fade" id="largeModalmasukDisposisi<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($data->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="row bg-title">
                    <!-- .page title -->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Surat Keluar Terbaru</h4>
                    </div>
                    <!-- /.page title -->
                    

                </div>

                  <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Data Surat Keluar</h3>
                            <p class="text-muted m-b-30">List surat keluar terbaru</p>
                            <div class="table-responsive">
                                <table id="myTable2" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Index</th>
                                            <th>Dari</th>
                                            <th>Tujuan</th>
                                            <th>Perihal</th>
                                            <th>Tgl/Nomor Surat Keluar</th>
                                            <th>Tgl Surat Keluar</th>
                                            <th>Jenis Surat</th>
                                            <th>Dokumen</th>
                                            <th>Dokumen Tanda Tangan</th>
                                            <th>Disposisi</th>
                                            <th>Diteruskan Kepada</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $suratkeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <td><?php echo e($data->indeks); ?></td>
                                            <td><?php echo e($data->dari); ?></td>
                                            <td><?php echo e($data->tujuan); ?></td>
                                            <td><?php echo e($data->perihal); ?></td>
                                            <td><?php echo e($data->tgl_no_suratkeluar); ?></td>
                                            <td><?php echo e($data->tgl_suratkeluar); ?></td>
                                            <?php if($data->jenis_surat == 'Express'): ?>
                                                <td><h4><span class="label label-danger label-rouded"><?php echo e($data->jenis_surat); ?></span></h4></td>
                                            <?php elseif($data->jenis_surat == 'Standar'): ?>
                                                <td><h4><span class="label label-success label-rouded"><?php echo e($data->jenis_surat); ?></span></h4></td>
                                            <?php endif; ?>
                                            <td>
                                                <a href="#" class="btn btn-info" data-toggle="modal" data-target="#largeModalkeluar<?php echo e($data->id); ?>">Preview<br>&<br>Cetak Surat</a></td>
                                            <?php if($data->url_dokumen_ttd != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalkeluarTTD<?php echo e($data->id); ?>">Tampil Surat</a></td>
                                            <?php else: ?>
                                                <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalkeluarTTD<?php echo e($data->id); ?>">Tampil Surat</a></td>
                                            <?php endif; ?>
                                                <?php if($data->url_disposisi != null): ?>
                                            <td><a href="#" class="btn btn-success" data-toggle="modal" data-target="#largeModalkeluarDisposisi<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php else: ?>
                                            <td><a href="#" class="btn btn-danger" data-toggle="modal" data-target="#largeModalkeluarDisposisi<?php echo e($data->id); ?>">Disposisi</a></td>
                                            <?php endif; ?>
                                            <td><?php echo e($data->kepada); ?></td>
                                            <?php if($data->status == 'Terkirim'): ?>
                                                <td><h4><span class="label label-info label-rouded"><?php echo e($data->status); ?></span></h4></td>
                                                <td></td>
                                            <?php elseif($data->status == 'Sudah Disposisi'): ?>
                                                <td><h4><span class="label label-success label-rouded"><?php echo e($data->status); ?></span></h4></td>
                                                <td><a href="<?php echo e(route('admin.detaildk.kabid',$data->id)); ?>" class="btn btn-danger">Detail Disposisi</a></td>
                                            <?php elseif($data->status == 'Disposisi ttd-Manual'): ?>
                                                <td><h4><span class="label label-success label-rouded"><?php echo e($data->status); ?></span></h4></td>
                                                <td><a href="<?php echo e(route('admin.detaildk.kabid',$data->id)); ?>" class="btn btn-danger">Detail Disposisi</a></td>
                                            <?php else: ?>
                                                <td><h4><span class="label label-warning label-rouded"><?php echo e($data->status); ?></span></h4></td>
                                                <td></td>
                                            <?php endif; ?>
                                        </tr>
                                        <div class="modal fade" id="largeModalkeluar<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($data->url_dokumen)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($data->url_disposisi != null): ?>
                                        <div class="modal fade" id="largeModalkeluarDisposisi<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <iframe src="<?php echo e(url($data->url_disposisi)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                        <?php if($data->url_dokumen_ttd != null): ?>
                                            <div class="modal fade" id="largeModalkeluarTTD<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title" id="myModalLabel">PDF</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <iframe src="<?php echo e(url($data->url_dokumen_ttd)); ?>" height="600" width="850" frameborder="0"></iframe>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            
                        </div> 
                        </div>
                    </div>
                </div>



                <!-- /.row -->
                <script src="<?php echo e(asset('js/pdfobject.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>